#!/bin/bash

SCRIPT_NAME=$(basename "$0")
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

LOG_FILE="report_${SCRIPT_NAME%.sh}.log"
BASE_NAME="${SCRIPT_NAME%.sh}"
LOG_FILE="report_${BASE_NAME}.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] $1" >> "$LOG_FILE"
}

log "Скрипт запущен"

FIFO="/tmp/run/cuckoo.pid"
ANSWER_FILE="/tmp/cuckoo_answer.txt"

if [[ ! -p "$FIFO" ]]; then
    log "Ошибка: канал $FIFO не найден"
    exit 1
fi

REQUEST="${BASE_NAME}[$$]: how much time do I have?"

echo "$REQUEST" > "$FIFO"

rm -f "$ANSWER_FILE"
timeout=5
while [[ ! -f "$ANSWER_FILE" ]]; do
    sleep 0.1
    ((timeout--))
    if [[ $timeout -le 0 ]]; then
        log "Ошибка: не дождались ответа от сервера"
        exit 1
    fi
done

N=$(cat "$ANSWER_FILE")
if [[ ! "$N" =~ ^[0-9]+$ ]] || [[ $N -lt 2 ]] || [[ $N -gt 10 ]]; then
    log "Ошибка: получено некорректное число '$N'"
    exit 1
fi

log "Получено время ожидания: $N секунд"
sleep "$N"
log "Скрипт завершился, работал $N секунд"
