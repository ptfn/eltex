#!/bin/bash

CONF_FILE="observer.conf"
LOG_FILE="observer.log"
WORKDIR="$(pwd)"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

if [[ ! -f "$CONF_FILE" ]]; then
    log "Файл конфигурации $CONF_FILE не найден"
    exit 1
fi

while IFS= read -r script_name; do
    [[ -z "$script_name" || "$script_name" =~ ^# ]] && continue
    
    if [[ ! -x "$WORKDIR/$script_name" ]]; then
        log "Ошибка: $script_name не найден или не исполняемый"
        continue
    fi
    
    found=0
    for pid in /proc/[0-9]*; do
        if [[ -f "$pid/comm" ]]; then
            comm=$(cat "$pid/comm")
            if [[ "$comm" == "$script_name" ]]; then
                found=1
                break
            fi
        fi
    done
    
    if [[ $found -eq 0 ]]; then
        nohup "$WORKDIR/$script_name" > /dev/null 2>&1 &
        log "Запущен $script_name (PID $!)"
    fi
done < "$CONF_FILE"
