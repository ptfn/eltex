#!/bin/bash

LOG_FILE="cuckoo.log"
FIFO_DIR="/tmp/run"
FIFO_NAME="cuckoo.pid"
FIFO_PATH="${FIFO_DIR}/${FIFO_NAME}"
ANSWER_FILE="/tmp/cuckoo_answer.txt"

mkdir -p "$FIFO_DIR"
[[ -e "$FIFO_PATH" ]] && rm -f "$FIFO_PATH"
mkfifo "$FIFO_PATH"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

shutdown() {
    log "Shutdown!"
    rm -f "$FIFO_PATH" "$ANSWER_FILE"
    exit 0
}
trap shutdown SIGTERM SIGINT

log "Startup!"

while true; do
    if read -r request < "$FIFO_PATH"; then
        if [[ "$request" =~ ^(.+)\[(.+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            name="${BASH_REMATCH[1]}"
            pid="${BASH_REMATCH[2]}"
            N=$((RANDOM % 9 + 2))
            log "${name}[${pid}] ${N}"
            echo "$N" > "$ANSWER_FILE"
        fi
    fi
done
